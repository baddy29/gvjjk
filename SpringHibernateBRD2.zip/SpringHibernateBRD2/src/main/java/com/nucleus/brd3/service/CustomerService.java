package com.nucleus.brd3.service;

import java.util.List;

import com.nucleus.brd3.model.persistence.entity.Customer;
/********************************************************           
 * CustomerService --Interface For Dao Operations       *   
 *                                                      *   
 * Author:  SHIAVM SHRIVASTAV                           *   
 *                                                      *   
 * Purpose: To declare All the methods in Dao           *   
 *                                                      *   
 * Usage:                                               *   
 *      Declares and makes outline for DaoImp	        *   
 ********************************************************/

//interface for customer service
public interface CustomerService {
	
	public void saveRecord(Customer customer);	
	public Customer getRecordByCustomerId(String customer_code);
	public void deleteRecordByCustomerCode(String customer_code);
	public Customer update2(Customer customer);
	public Customer update1(String customerid);
	public List<Customer> show() ;
	public List<Customer> viewByName(String customer_name);
	public void saveRecord2(Customer customer, String countryName);	

	
}
