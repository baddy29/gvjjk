package com.nucleus.brd3.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nucleus.brd3.model.persistence.dao.CountryDao;
import com.nucleus.brd3.model.persistence.dao.CustomerDao;
import com.nucleus.brd3.model.persistence.entity.Country;
import com.nucleus.brd3.model.persistence.entity.Customer;

@Service
public class CountryServiceImpl implements CountryService{

	@Autowired
	CountryDao countryDao;//injecting country dao bean
	
	@Transactional
	public List<Country> show() {
		return countryDao.show();
	}

}
