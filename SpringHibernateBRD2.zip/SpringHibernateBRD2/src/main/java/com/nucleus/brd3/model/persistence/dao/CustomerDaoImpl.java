package com.nucleus.brd3.model.persistence.dao;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.nucleus.brd3.controller.LoginController;
import com.nucleus.brd3.model.persistence.entity.Country;
import com.nucleus.brd3.model.persistence.entity.Customer;
import com.sun.org.apache.regexp.internal.recompile;
/********************************************************           
 * CustomerDaoImpl --Implements the interface           *   
 *                                                      *   
 * Author:  SHIAVM SHRIVASTAV                           *   
 *                                                      *   
 * Purpose: To Perform crud operation                   *   
 *                                                      *   
 * Usage:                                               *   
 *      Crud operations are performed through this      *   
 ********************************************************/  

	@Repository
	public class CustomerDaoImpl implements CustomerDao
	{

		final static Logger LOGGER=Logger.getLogger(CustomerDaoImpl.class);

		@Autowired
	    SessionFactory sessionFactory;//loading session factory
		
		
		private Customer customer1=null;
		private Country country=null;

		//implementing insertion 
		public void saveRecord(Customer customer) 
		{	
			Date date=new Date();
			SimpleDateFormat simpleDateFormat=new SimpleDateFormat("dd/MM/yyyy");
			customer.setCreate_date(simpleDateFormat.format(date));
//			customer.setCreated_by();
			try{
			sessionFactory.getCurrentSession().save(customer);	
		}
			catch(Exception e)
			{
				LOGGER.error("Exception in saving customer record");
			}
		}
		
//================================================================================================		 
		
		//performing delete customer
		public void deleteRecordByCustomerCode(String customer_code) 
		{
			Customer customer=(Customer)sessionFactory.getCurrentSession().load(Customer.class,customer_code);
			try
			{
				this.sessionFactory.getCurrentSession().delete(customer);
			}
			catch(Exception e)
			{
				LOGGER.error("Exception in deleting customer record");
			}
		}
//================================================================================================
		
		//get customer by code
		public Customer getRecordByCustomerId(String customer_code) 
		{
			try{
			customer1=(Customer)sessionFactory.getCurrentSession().get(Customer.class, customer_code);
			return customer1 ;
			
			}
			catch(Exception e)
			{
				LOGGER.error("Exception ingetting customer record by customer code");
				return null;
			}
			
		}
//================================================================================================
		//@SuppressWarnings("unchecked")
		 
		//get list of all customers
		public List<Customer> show() 
		{
			List<Customer> list1=null;
			 list1= new ArrayList<Customer>() ;
			
			try{
			
			Query query=sessionFactory.getCurrentSession().createQuery("from Customer");
			list1=query.list();
			return list1;
			
			}
			catch(Exception e)
			{
				LOGGER.error("Exception in getting customer list");
				return null;
			}
			
		}
//================================================================================================
		
		//update customer
		public Customer update2(Customer customer) 
		{
			try{
			sessionFactory.getCurrentSession().update(customer);
			return customer;
			}
			catch(Exception e)
			{
				LOGGER.error("Exception in updating customer");
				return null;
			}
			

		}
//================================================================================================		 
		
		//getting customer by code for update
		public Customer update1(String customer_code) 
		{
			try{
				LOGGER.debug("In update1");
			customer1=(Customer)sessionFactory.getCurrentSession().get(Customer.class, customer_code);
			return customer1; 
			
			}
			catch(Exception e)
			{
				LOGGER.error("Exception in updating customer");
				return null;
			}
			
		}
		
//==========================================================================================		
		 
		//Customer list view by name
		public List<Customer> viewByName(String customer_name) 
		{
			List<Customer> list1;
			 list1= new ArrayList<Customer>() ;
			Query query=sessionFactory.getCurrentSession().createQuery("select u from Customer u where u.customer_name=:name");
			query.setParameter("name", customer_name);
			list1=query.list();
			System.out.println(list1);
			return list1;
	
		}
//==========================================================================================
		
		
		public void saveRecord2(Customer customer, String countryName) {
			
			/*Country country= new Country(countryName);*/
			country=(Country)sessionFactory.getCurrentSession().get(Country.class, countryName);
			
			
			
			/*country.get(0).getCountryCode();
			*/
			customer.setCountry_code(country);
			sessionFactory.getCurrentSession().save(customer);
			
		}

	
	}
	