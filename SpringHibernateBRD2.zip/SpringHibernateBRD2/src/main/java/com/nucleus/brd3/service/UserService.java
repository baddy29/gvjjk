package com.nucleus.brd3.service;

public interface UserService {

}
