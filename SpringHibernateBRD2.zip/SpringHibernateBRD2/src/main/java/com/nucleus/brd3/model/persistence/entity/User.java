package com.nucleus.brd3.model.persistence.entity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/********************************************************           
 * Role --POJO class for User		                    *   
 *                                                      *   
 * Author: 	SHIAVM SHRIVASTAV                           *   
 *                                                      *   
 * Purpose: To Store All User related data              *   
 *                                                      *   
 * Usage:                                               *   
 *     works As Class to store All the data of User     *   
 ********************************************************/
@Entity
@Table(name="User_Brd3_18060169")
@SequenceGenerator(name="auserSequence", sequenceName="auserSequence", allocationSize=2)
public class User implements Serializable
{
	@Override
	public String toString() {
		return "User [userId=" + userId + ", username=" + username
				+ ", password=" + password + ", enabled=" + enabled + ", role="
				+ role + "]";
	}
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="auserSequence")
	@Column(unique=true)
	private int userId;
	private String username;
	private String password;
	private int enabled;
	
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="roleId")
	private Role role;
	
	public User()
	{}
	
	public User(String username, String password,int enabled) {
		// TODO Auto-generated constructor stub
		super();
		this.username=username;
		this.password=password;
		this.enabled=enabled;
	}
	
	
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Role getRole() {
		return role;
	}
	public void setRole(Role role) {
		this.role = role;
	}
	public int getEnabled() {
		return enabled;
	}
	public void setEnabled(int enabled) {
		this.enabled = enabled;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	
	
}
