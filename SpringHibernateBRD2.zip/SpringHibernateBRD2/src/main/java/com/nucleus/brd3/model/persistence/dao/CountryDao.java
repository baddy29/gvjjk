package com.nucleus.brd3.model.persistence.dao;

import java.util.List;

import com.nucleus.brd3.model.persistence.entity.Country;
import com.nucleus.brd3.model.persistence.entity.Customer;


public interface CountryDao {
	public List<Country> show() ;
}
