package com.nucleus.brd3.model.persistence.dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.nucleus.brd3.model.persistence.entity.Country;
import com.nucleus.brd3.model.persistence.entity.Customer;

@Repository
public class CountryDaoImpl implements CountryDao {

	@Autowired
    SessionFactory sessionFactory;//loading session factory
	
	
	public List<Country> show() {
		List<Country> list1=null;
		 list1= new ArrayList<Country>() ;
		 
		 final Logger LOGGER=Logger.getLogger(CountryDaoImpl.class);
		
		try{
		
		Query query=sessionFactory.getCurrentSession().createQuery("from Country");
		list1=query.list();
		return list1;
		
		}
		catch(Exception e)
		{
			LOGGER.error("Exception in getting customer list");
			return null;
		}
		
	}

}
