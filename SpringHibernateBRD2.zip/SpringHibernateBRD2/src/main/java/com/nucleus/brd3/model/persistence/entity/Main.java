package com.nucleus.brd3.model.persistence.entity;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;

@SuppressWarnings("deprecation")
public class Main {

	public static void main(String[] args) {

		/*SessionFactory factory=null;
		
		
		try{
			factory=new AnnotationConfiguration()
			.configure().buildSessionFactory();
			
			Session session=factory.openSession();
			session.getTransaction().begin();*/

			
			
			/*Role role=new Role("U","User");
			session.save(role);
			role.setId(2);
			User user = new User("user", "$2a$12$ibVdls0k/2IcfZqRSMZ7uexpotC3B9pKhriC4NCRz3PnVqA.BQUQS",1,role);
			session.save(user);
			
			Query q=session.createQuery("select u from User u where u.username=:name and u.password=:password");
			q.setString("name", "ss");
			q.setString("password", "abc");
			


			
			
	
			
			session.getTransaction().commit();
			session.close();
			
			
			
			
		
		}finally{
			if(factory!=null)
			factory.close();
		}
		
		
	}*/

		}
}

