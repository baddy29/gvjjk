package com.nucleus.brd3.service;

import java.util.List;

import com.nucleus.brd3.model.persistence.entity.User;

/********************************************************           
 * UserService --Interface For Dao Operations           *   
 *                                                      *   
 * Author:  SHIAVM SHRIVASTAV                           *   
 *                                                      *   
 * Purpose: To declare All the methods in Dao           *   
 *                                                      *   
 * Usage:                                               *   
 *      Declares and makes outline for DaoImp	        *   
 ********************************************************/

//interface for user services
public interface RoleService {

	public void saveRecord(User user);
	public List<User> viewUserName(); 
	public String encodePwd(String pwd);

}
