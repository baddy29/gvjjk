package com.nucleus.brd3.model.persistence.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="State_BRD3_18060169")
@SequenceGenerator(name="auserSequence", sequenceName="auserSequence", allocationSize=2)
public class State {

	@Id
	@NotNull
	@Column(unique=true)
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="auserSequence")
	String stateCode;
	
	@NotNull
	String statename;
	
	/*@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="countryCode")
	private Country country;*/

	public String getStateCode() {
		return stateCode;
	}

	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}

	public String getStatename() {
		return statename;
	}

	public void setStatename(String statename) {
		this.statename = statename;
	}

	@Override
	public String toString() {
		return "State [stateCode=" + stateCode + ", statename=" + statename
				+ ", country=" +  "]";
	}

	/*public Country getCountry() {
		return country;
	}

	public void setCountry(Country country) {
		this.country = country;
	}*/
}
