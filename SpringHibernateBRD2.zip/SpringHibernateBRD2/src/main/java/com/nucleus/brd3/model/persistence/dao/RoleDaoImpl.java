package com.nucleus.brd3.model.persistence.dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.nucleus.brd3.controller.LoginController;
import com.nucleus.brd3.model.persistence.entity.User;

/********************************************************           
 * RoleDaoImpl --Implements the interface   	        *   
 *                                                      *   
 * Author:  SHIAVM SHRIVASTAV                           *   
 *                                                      *   
 * Purpose: To Perform crud operation                   *   
 *                                                      *   
 * Usage:                                               *   
 *      Crud operations are performed through this      *   
 ********************************************************/  



@Repository
public class RoleDaoImpl implements RoleDao
{
	
	final static Logger LOGGER=Logger.getLogger(RoleDaoImpl.class);

	
	@Autowired
	SessionFactory sessionFactory;//loading session factory
	
	
	@Autowired
	BCryptPasswordEncoder bCryptPasswordEncoder;
	
	
	

	
	//adding new user 
	public void saveRecord(User user) {
		
		try{
		user.setEnabled(1);
		String enocodedpassword=encodePwd(user.getPassword());
		user.setPassword(enocodedpassword);
		
		sessionFactory.getCurrentSession().saveOrUpdate(user);	
		}
		
		catch(Exception e)
		{
			LOGGER.error("Exception in saving user record");
		}
	}

	//getting list of all users 
	public List<User> viewUserName() 
	{
		List<User> userName=new ArrayList<User>();
		try{
		Query query=sessionFactory.getCurrentSession().createQuery("from User");
		userName=query.list();
		return userName;
		
		}
		catch(Exception e)
		{
			e.printStackTrace();	
			LOGGER.error("Exception in generating user name");
			return null;
		}
		
	}
	
	public String encodePwd(String pwd) 
	{
		return bCryptPasswordEncoder.encode(pwd);
		
	}


}
