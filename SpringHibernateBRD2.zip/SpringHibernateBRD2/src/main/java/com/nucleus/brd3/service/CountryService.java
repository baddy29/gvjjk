package com.nucleus.brd3.service;

import java.util.List;

import com.nucleus.brd3.model.persistence.entity.Country;
import com.nucleus.brd3.model.persistence.entity.Customer;

public interface CountryService {

	public List<Country> show() ;
	
}
