package com.nucleus.brd3.model.persistence.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/********************************************************           
 * Role --POJO class for User		                    *   
 *                                                      *   
 * Author:  SHIAVM SHRIVASTAV                           *   
 *                                                      *   
 * Purpose: To Store All User related data              *   
 *                                                      *   
 * Usage:                                               *   
 *     works As Class to store All the data of User     *   
 ********************************************************/ 


@Entity
@Table(name="Profile_Brd3_18060169")
@SequenceGenerator(name="aRoleSequence" ,  sequenceName=" aRoleSequence" , allocationSize=2)
public class Role implements Serializable 
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE , generator="aRoleSequence")
	@Column(unique=true)
	private int roleId;
	private String roleName;
	
	public Role()
	{}
	
	public Role(String role)
	{
		/*System.out.println("========================"+role);*/
		if(role.equalsIgnoreCase("admin"))
			roleName="ROLE_ADMIN";
		else if(role.equalsIgnoreCase("user"))
			roleName="ROLE_USER";
		else
			/*System.out.println(role+"   :No role set");*/
			roleName="NULL";
	}
	
	@Override
	public String toString() {
		return "Role [roleId=" + roleId + ", roleName=" + roleName + "]";
	}
	public int getRoleId() {
		return roleId;
	}
	public void setRoleId(int roleId) {
		this.roleId = roleId;
	}
	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
}
