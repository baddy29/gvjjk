package com.nucleus.brd3.model.persistence.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="Country_BRD3_18060169")
@SequenceGenerator(name="auserSequence", sequenceName="auserSequence", allocationSize=2)
public class Country {

	@Id
	@NotNull
	@Column(unique=true)
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="auserSequence")
	private int countryCode;
	
	public int getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(int countryCode) {
		this.countryCode = countryCode;
	}

	@Override
	public String toString() {
		return "Country [countryCode=" + countryCode + ", countryname="
				+ countryName + "]";
	}

	public String getCountryname() {
		return countryName;
	}

	public void setCountryname(String countryname) {
		this.countryName = countryname;
	}

	public Country() {
		// TODO Auto-generated constructor stub
	}
	
	private String countryName;

	public Country(String countryName) {
		super();
		this.countryName = countryName;
	}
	
}
